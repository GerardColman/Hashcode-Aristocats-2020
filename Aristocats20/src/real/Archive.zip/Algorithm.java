package real;

public class Algorithm {
}
