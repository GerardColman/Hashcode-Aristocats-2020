package real;

import java.util.ArrayList;

public class Output
{
    BooksScanned scanned = null;
    public Output(BooksScanned scanned)
    {
        this.scanned = scanned;
    }
}
