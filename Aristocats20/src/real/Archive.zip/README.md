## ToDo List:
 - [X] Create Book Class
 - [X] Create Library Class
 - [X] Create BooksScanned
  
 ## Library Class
 - [X] Store an ArrayList of Books
 - [X] The ID of the Library
 - [X] The number of Books to be scanned each day once the Library is signed up
 - [X] Total value of the books in the library
 
 ## BooksScanned Class
 - [X] HashMap of BookID and Bool isScanned
 - [X] Takes new BookID from Books Class
 - [X] int daysLeft
 - [X] ArrayList<Library> libraryScanned
 - [X] signUpLibrary() method 
 - [X] BooksScanned 
 
 ## Books Class
 - [X] Book Object
    - [X] Stores the BookID and the value of the book
 