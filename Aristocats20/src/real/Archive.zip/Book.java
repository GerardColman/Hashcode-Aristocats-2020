package real;

public class Book
{
    int b_id = -1;
    int value = -1;

    public Book(int id, int value) {
        this.b_id = id;
        this.value = value;
    }

    public String toString()
    {
        return "[" + b_id + " : " + value + "]";
    }
}
